const mysql = require('mysql'); 
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'nodeapps'
});

exports.postLogin = (req, res) => {
  const { email, password } = req.body;
  const encryptedPassword = encrypt(password, 3);

  connection.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, encryptedPassword], (err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      return res.status(500).send('Error executing query');
    }
    if (results.length > 0) {
      res.redirect('home');
    } else {
      res.render('login', { errorMessage: 'Invalid username or password' });
    }
  });
};

exports.getLogin = (req, res) => {
  res.render('login');
};

function encrypt(text, shift) {
  let result = '';
  for (let i = 0; i < text.length; i++) {
    let char = text.charAt(i);
    if (/[a-zA-Z]/.test(char)) {
      let code = text.charCodeAt(i);
      if (code >= 65 && code <= 90) {
        char = String.fromCharCode(((code - 65 + shift) % 26) + 65);
      }
      else if (code >= 97 && code <= 122) {
        char = String.fromCharCode(((code - 97 + shift) % 26) + 97);
      }
    }
    else if (/[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(char)) {
      let code = text.charCodeAt(i);
      char = String.fromCharCode((code + shift) % 128);
    }
    result += char;
  }
  return result;
}
